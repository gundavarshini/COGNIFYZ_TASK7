
const db = require("../config/db");

const User = {
    async findByEmail(email) {
        const [rows] = await db.execute(
            `SELECT id, full_name, email, password, created_at
             FROM users
             WHERE email = ?`,
            [email]
        );

        return rows[0] || null;
    },

    async findById(id) {
        const [rows] = await db.execute(
            `SELECT id, full_name, email, created_at
             FROM users
             WHERE id = ?`,
            [id]
        );

        return rows[0] || null;
    },

    async create(fullName, email, hashedPassword) {
        const [result] = await db.execute(
            `INSERT INTO users (full_name, email, password)
             VALUES (?, ?, ?)`,
            [fullName, email, hashedPassword]
        );

        return result.insertId;
    }
};

module.exports = User;
