
const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");

const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");

const authView = document.getElementById("authView");
const profileView = document.getElementById("profileView");

const messageBox = document.getElementById("message");
const profileMessage = document.getElementById("profileMessage");
const logoutButton = document.getElementById("logoutButton");

function showMessage(element, message, type = "error") {
    element.textContent = message;
    element.className = `message ${type}`;
    element.hidden = false;
}

function clearMessage(element) {
    element.textContent = "";
    element.hidden = true;
}

function switchTab(mode) {
    const isLogin = mode === "login";

    loginForm.hidden = !isLogin;
    registerForm.hidden = isLogin;

    loginTab.classList.toggle("active", isLogin);
    registerTab.classList.toggle("active", !isLogin);

    clearMessage(messageBox);
}

loginTab.addEventListener("click", () => switchTab("login"));
registerTab.addEventListener("click", () => switchTab("register"));

async function apiRequest(url, options = {}) {
    const response = await fetch(url, {
        ...options,
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json",
            ...options.headers
        }
    });

    const data = await response.json().catch(() => ({
        message: "The server returned an invalid response."
    }));

    if (!response.ok) {
        const error = new Error(
            data.message || "The request failed."
        );

        error.status = response.status;
        throw error;
    }

    return data;
}

function showProfile(user) {
    authView.hidden = true;
    profileView.hidden = false;

    document.getElementById("welcomeHeading").textContent =
        `Welcome, ${user.fullName}`;

    document.getElementById("profileName").textContent =
        user.fullName;

    document.getElementById("profileEmail").textContent =
        user.email;

    document.getElementById("profileId").textContent =
        String(user.id);

    clearMessage(profileMessage);
}

function showAuthentication() {
    profileView.hidden = true;
    authView.hidden = false;
    switchTab("login");
}

loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearMessage(messageBox);

    const button = loginForm.querySelector("button[type='submit']");
    button.disabled = true;

    try {
        const data = await apiRequest("/api/auth/login", {
            method: "POST",
            body: JSON.stringify({
                email: loginForm.elements.email.value,
                password: loginForm.elements.password.value
            })
        });

        loginForm.reset();
        showProfile(data.user);
    } catch (error) {
        showMessage(messageBox, error.message);
    } finally {
        button.disabled = false;
    }
});

registerForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearMessage(messageBox);

    const fullName = registerForm.elements.fullName.value.trim();
    const email = registerForm.elements.email.value.trim();
    const password = registerForm.elements.password.value;
    const confirmPassword =
        registerForm.elements.confirmPassword.value;

    if (password !== confirmPassword) {
        showMessage(messageBox, "Passwords do not match.");
        return;
    }

    const button = registerForm.querySelector("button[type='submit']");
    button.disabled = true;

    try {
        const data = await apiRequest("/api/auth/register", {
            method: "POST",
            body: JSON.stringify({
                fullName,
                email,
                password,
                confirmPassword
            })
        });

        registerForm.reset();
        switchTab("login");

        showMessage(messageBox, data.message, "success");
    } catch (error) {
        showMessage(messageBox, error.message);
    } finally {
        button.disabled = false;
    }
});

logoutButton.addEventListener("click", async () => {
    logoutButton.disabled = true;
    clearMessage(profileMessage);

    try {
        const data = await apiRequest("/api/auth/logout", {
            method: "POST",
            body: JSON.stringify({})
        });

        showAuthentication();
        showMessage(messageBox, data.message, "success");
    } catch (error) {
        showMessage(profileMessage, error.message);
    } finally {
        logoutButton.disabled = false;
    }
});

async function checkSession() {
    try {
        const data = await apiRequest("/api/users/me");
        showProfile(data.user);
    } catch (error) {
        showAuthentication();
    }
}

checkSession();
