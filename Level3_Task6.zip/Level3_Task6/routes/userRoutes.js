
const express = require("express");
const router = express.Router();

const User = require("../models/User");
const authMiddleware = require("../middleware/authMiddleware");

router.get("/me", authMiddleware, async (req, res) => {
    try {
        const user = await User.findById(req.session.userId);

        if (!user) {
            return res.status(404).json({
                message: "User account not found."
            });
        }

        return res.json({
            user: {
                id: user.id,
                fullName: user.full_name,
                email: user.email,
                createdAt: user.created_at
            }
        });
    } catch (error) {
        console.error("Profile error:", error.message);

        return res.status(500).json({
            message: "Unable to retrieve user profile."
        });
    }
});

module.exports = router;
