
require("dotenv").config();

const express = require("express");
const session = require("express-session");
const MySQLStore = require("express-mysql-session")(session);
const path = require("path");

const db = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const userRoutes = require("./routes/userRoutes");

const app = express();
const PORT = Number(process.env.PORT) || 5000;

if (!process.env.SESSION_SECRET) {
    throw new Error("SESSION_SECRET is missing from .env");
}

const sessionStore = new MySQLStore({
    host: process.env.DB_HOST || "localhost",
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    database: process.env.DB_NAME || "cognifyz_auth",
    clearExpired: true,
    checkExpirationInterval: 15 * 60 * 1000,
    expiration: 24 * 60 * 60 * 1000
});

app.disable("x-powered-by");

app.use(express.json({ limit: "10kb" }));
app.use(express.urlencoded({
    extended: false,
    limit: "10kb"
}));

app.use(session({
    name: "connect.sid",
    secret: process.env.SESSION_SECRET,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 24 * 60 * 60 * 1000
    }
}));

app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", async (req, res) => {
    try {
        await db.query("SELECT 1");

        return res.json({
            status: "OK",
            message: "Server and MySQL are connected."
        });
    } catch (error) {
        return res.status(503).json({
            status: "ERROR",
            message: "Database connection unavailable."
        });
    }
});

app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);

app.use("/api", (req, res) => {
    res.status(404).json({
        message: "API endpoint not found."
    });
});

app.use((error, req, res, next) => {
    console.error("Server error:", error.message);

    if (res.headersSent) {
        return next(error);
    }

    return res.status(500).json({
        message: "An unexpected server error occurred."
    });
});

async function startServer() {
    try {
        await db.query("SELECT 1");
        await sessionStore.onReady();

        app.listen(PORT, () => {
            console.log(`Server running at http://localhost:${PORT}`);
            console.log("MySQL database connected successfully.");
        });
    } catch (error) {
        console.error("Application startup failed:", error.message);
        process.exit(1);
    }
}

startServer();
